                <!-- Main row -->
<div class="row" ng-controller="Controller">


<div class="col-md-7">

<div class="box box-default">
        <div class="box-header with-border">
          <h3 class="box-title">Cotrol de Planta Hemodialisis</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
          </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body">

          <div class="row">

                  <div>
                    <div class="btn-group" >
                  <button type="button" class="btn btn-default btn-sm active" ng-if="Planta.Status==1"><i class="fa fa-square text-green"></i>
                  </button>
                  <button type="button" class="btn btn-default btn-sm" ng-if="Planta.Status==0"><i class="fa fa-square text-red"></i></button>
                </div>

                  </div>
            

          </div>


          <div clas="row">

 <div class="col-sm-offset-7 col-sm-5 pull-right">
                <div class="btn-group">
                      <button type="button" class="btn btn-success" id="inicializar"  ng-click="InicioPlanta()">Start</button>
                      <button type="button" ng-click="DetenerPlanta()" id="stop" class="btn btn-danger">Stop</button>
                      <button type="button" ng-click="ResetPlanta()" class="btn btn-info">Reset</button>
                  </div>
  </div>
            <div class="col-sm-3"> 
              <img src="<?php echo base_url(); ?>/webApp/img/CODI/tinaco_1.png">
            </div>

            <div class="col-sm-9">            
                  <img src="<?php echo base_url(); ?>/webApp/img/CODI/{{Planta.img}}" width="100%">
             
              
              
            </div>
                   
          </div>
          <!-- /.row -->
        </div>
         
        <!-- /.box-body -->       
      </div>

</div>


<div class="col-md-5">

  <div class="box box-default">
            <div class="box-header with-border">
              <h3 class="box-title">Log de Actividades</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">

               <div class="col-sm-12">
                 <table class="table table-striped">
                <tbody><tr>
                  <th style="width: 10px">#</th>
                  <th>Task</th>                 
                </tr>
                <tr ng-repeat="(k, val) in Planta.Log">
                  <td>{{(k+1)}}</td>
                  <td>{{val.Msg}}</td>
                </tr>
               
              </tbody></table>
               </div>

               
                         
            </div>
            <!-- /.footer -->
          </div>


  </div>

          <!-- Custom Tabs -->
         
          <!-- nav-tabs-custom -->
  
    </div>

</div>


<script type="text/javascript">
  
 var db = firebase.database().ref('home');

  db.update({
    led1:false
  });
// último estado/*


$("#inicializar").click(function(){
 
  db.update({
    led1:true
  });
});

$("#stop").click(function(){
 
  db.update({
    led1:false
  });
});
</script>
