<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>CODI | Log in</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo base_url(). "webApp"; ?>/Dist/bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url(). "webApp"; ?>/Dist/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo base_url(). "webApp"; ?>/Dist/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url(). "webApp"; ?>/Dist/LTE/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?php echo base_url(). "webApp"; ?>/Dist/iCheck/square/blue.css">

  <script type="text/javascript">
   
            var base_url = "<?php echo base_url(); ?>";     
  </script>

      <script src="<?php echo base_url(). "webApp"; ?>/js/App/Controller/Controllers.js"></script>

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
</head>
<body class="hold-transition login-page" ng-app="AppSupply">
<div class="login-box" ng-controller="AppController" ng-init="inicial()">
  <div class="login-logo">
    <a ng-click='example()'"><b>CODI</b></a>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">Entra a tu session </p>

    <form action="../../index2.html" method="post">
      <div class="form-group has-feedback">
        <input type="email" class="form-control" placeholder="Email" ng-model="user.Email">
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" placeholder="Password" ng-model="user.Password">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
        <div class="col-xs-8">
          <div class="checkbox icheck">
            <label>
              <input type="checkbox"> Remember Me
            </label>
          </div>
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="button" class="btn btn-primary btn-block btn-flat" ng-click='login()'>Sign In</button>
        </div>
        <!-- /.col -->
      </div>
    </form>

    <div class="social-auth-links text-center">
     
    </div>
    <!-- /.social-auth-links -->

    <a href="#">Olvide mi contrasena</a><br>

  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 3 -->
<script src="<?php echo base_url(). "webApp"; ?>/Dist/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo base_url(). "webApp"; ?>/Dist/bootstrap/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="<?php echo base_url(). "webApp"; ?>/Dist/iCheck/icheck.min.js"></script>

<script src="<?php echo base_url(). "webApp"; ?>/Dist/angularJS/angular.js"></script>
        <script src="<?php echo base_url(). "webApp"; ?>/Dist/angularJS/angular-sanitize.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(). "webApp"; ?>/Dist/Jcs-auto-validate/jcs-auto-validate.js"></script>
    <script type="text/javascript" src="<?php echo base_url(). "webApp"; ?>/Dist/Oi.multiselect/multiselect-tpls.min.js"></script><!--angular-oi.multiselect-->
    <script type="text/javascript" src="<?php echo base_url(). "webApp"; ?>/Dist/sortable/sortable.js"></script>
    
    <script src="<?php echo base_url(). "webApp"; ?>/js/App/App.js"></script>
    <script src="<?php echo base_url(). "webApp"; ?>/js/App/AppValidation.js"></script>
    <script src="<?php echo base_url(). "webApp"; ?>/js/App/AppFormat.js"></script>
    <script src="<?php echo base_url(). "webApp"; ?>/js/App/AppTool.js"></script>

    <script src="<?php echo base_url(). "webApp"; ?>/js/App/Filter/Filters.js"></script>
    <script src="<?php echo base_url(). "webApp"; ?>/js/App/Directive/Directives.js"></script>
    <script src="<?php echo base_url(). "webApp"; ?>/js/App/Factory/Factories.js"></script>
    <script src="<?php echo base_url(). "webApp"; ?>/js/App/Service/Services.js"></script>
    <!-- end taggle -->

   <script src="<?php echo base_url(). "webApp"; ?>/Dist/animate/angular-animate.min.js"></script>
   <script src="<?php echo base_url(). "webApp"; ?>/Dist/angular-inform/angular-inform.min.js"></script>
    <!-- end chartjs -->
    <!-- AdminLTE for demo purposes --> -


<!-- ES FIREBASE COn ANgULAr -->
    <script src="https://www.gstatic.com/firebasejs/5.5.5/firebase.js"></script>
    <script src="https://www.gstatic.com/firebasejs/5.5.5/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/5.5.5/firebase-database.js"></script>
<script src="https://www.gstatic.com/firebasejs/5.5.5/firebase-firestore.js"></script>
<script src="https://www.gstatic.com/firebasejs/5.5.5/firebase-messaging.js"></script>
<script src="https://www.gstatic.com/firebasejs/5.5.5/firebase-functions.js"></script>
<!-- AngularFire -->



    <script src="<?php echo base_url(). "webApp"; ?>/Dist/bootstrap/js/boostrap-waiting.js"></script>
   <script src="<?php echo base_url(). "webApp"; ?>/Dist/jquery/js/jquery.blockUI.js"></script>
   <script src="<?php echo base_url(). "webApp"; ?>/Dist/datatables.net/js/jquery.dataTables.min.js"></script>
   <script src="<?php echo base_url(). "webApp"; ?>/Dist/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

       <script>


        if (typeof (gTechApp) == "undefined") {
            console.log("No Controller");
        } else {
            (function () { 

                gTechApp.Main(); 
            })();

        }
    </script>

<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
</body>
</html>
