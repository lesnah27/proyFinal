<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <title>CODI Control domotico integrado </title>
     <link rel="icon" href="<?php // echo $url_ico; ?>favicon.ico" rel="shortcut icon" type="image/x-icon"/>
     <link rel="shortcut icon" href="<?php // echo $url_ico; ?>favicon.ico" type="image/x-icon"/>   
     <meta name="viewport" content="width=device-width" />
    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/webApp/Dist/bootstrap/css/bootstrap.min.css">  
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Font Awesome -->
     <link rel="stylesheet" href="<?php echo base_url(); ?>/webApp/Dist/font-awesome/css/font-awesome.min.css">  
   
       <!-- Ionicons -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/webApp/Dist/Ionicons/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/webApp/Dist/LTE/AdminLTE.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/webApp/Dist/LTE/skins/_all-skins.min.css">
    <!-- Date Picker -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/webApp/Dist/bootstrap/css/bootstrap-datepicker.min.css">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/webApp/Dist/LTE/bootstrap3-wysihtml5.min.css">

    <link href="<?php echo base_url(); ?>/webApp/Dist/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet" />   
    <!-- Date Time Picker -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/webApp/Dist/bootstrap/css/bootstrap-datetimepicker.min.css">
    <!-- bootstrap-select/ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/webApp/Dist/bootstrap/css/bootstrap-select.min.css">

    <link rel="stylesheet" href="<?php echo base_url(); ?>/webApp/Dist/select2/select2.min.css">
    <!-- bootstrap-toggle/ -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>/webApp/Dist/bootstrap/css/bootstrap-toggle.min.css">

     <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/webApp/Dist/fileinput/css/fileinput.css" />

     <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/webApp/Dist/angular-inform/angular-inform.min.css"  />
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <!-- Google Font -->

    <style>
        .btn-appCrud {
            border-radius: 3px;
            position: relative;
            padding: 7px 5px;
            margin: 0 0 0px 2px;
            min-width: 49px;
            height: 48px;
            text-align: center;
            color: #666;
            border: 1px solid #ddd;
            background-color: #f4f4f4;
            font-size: 15px;
        }

        .btn-appCrud-del {
            border-radius: 3px;
            position: relative;
            padding: 7px 5px;
            margin: 0 0 0px 2px;
            min-width: 49px;
            height: 48px;
            text-align: center;
            color: #666;
            border: 1px solid #ddd;
            background-color: #e2cccc;
            font-size: 15px;
        }

        .personal-badge {
            right: 5px;
            top: 5px;
            position: absolute;
            padding: 3px 6px;
            background-color: #ce4844;
        }
    </style>
    <script type="text/javascript">
       var base_url = "<?php echo base_url(); ?>"; 

   
    </script>

        <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<!--// Inicio de firebase -->
<script src="https://www.gstatic.com/firebasejs/5.6.0/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyBRFNy7kcOPRrg8qLyngfVc2OAZS9-KRS8",
    authDomain: "pruev1-b7087.firebaseapp.com",
    databaseURL: "https://pruev1-b7087.firebaseio.com",
    projectId: "pruev1-b7087",
    storageBucket: "pruev1-b7087.appspot.com",
    messagingSenderId: "1097633572611"
  };
  firebase.initializeApp(config);
</script>
    <script src="<?php echo base_url(); ?>/webApp/js/App/Controller/Controllers.js"></script>
</head>

<body class="hold-transition skin-black sidebar-mini" ng-app="AppSupply">
    <div class="wrapper" ng-controller="AppController" ng-init="inicial()">
        <header class="main-header">
            <!-- Logo -->
            <a href="#" class="logo">
                <!-- mini logo for sidebar mini 50x50 pixels -->
                <span class="logo-mini"><b>
                   CODI</b></span>
                <!-- logo for regular state and mobile devices -->
                <span class="logo-lg" ng-click="hiceClick()">
                <b>CODI   </b>
                </span>
            </a>
            <!-- Header Navbar: style can be found in header.less -->
            <nav class="navbar navbar-static-top">
                <!-- Sidebar toggle button-->
                <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                    <span class="sr-only">Toggle navigation</span>
                </a>

                <div class="navbar-custom-menu">
                 
                  <li class="dropdown notifications-menu">
                                <a href="#" class="dropdown-toggle" id="dropdownMenu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="text-transform: uppercase">
                                    <i class="fa fa-gears"></i><span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" aria-labelledby="dropdownMenu">
                                    <!--<li> <a href="<?php echo base_url();  ?>portal/myAccount"> <i class="fa fa-gears"></i> <?php echo "configuracion"; ?></a> </li>
                                    <li> <a href="<?php echo base_url();  ?>portal/myData"> <i class="fa fa-user"></i> <?php echo "Mi_Perfil"; ?></a> </li>-->
                                    <li> 
                                        <a href="<?php echo base_url(). "";?>portal/logout" data-toggle="tooltip" data-placement="bottom" data-original-title="<?php echo "logout";  ?>">
                                            <i class="fa fa-sign-out"></i> <?php echo "Salir";  ?>
                                        </a>
                                    </li>
                                </ul>
                            </li>

                </div>
                  
            </nav>
        </header>
        <!-- Left side column. contains the logo and sidebar -->

        <aside class="main-sidebar">
            <!-- sidebar: style can be found in sidebar.less -->
            <section class="sidebar">
                <!-- Sidebar user panel -->
                <div class="user-panel">
                    <div class="pull-left image">
                       

                    </div>
                    <div class="pull-left info">
                        <p><?php // echo $sSessionUsuario["NombreCompleto"]; ?></p>
                        <a href="#"><i class="fa fa-circle text-success"></i> AA</a>                        
                    </div>
                </div>
                <div class="user-panel">            
                <form action="", id="22">       

              </form>
                </div>
                

                    <!-- search form -->


                    <form action="#" method="get" class="sidebar-form">
                        <div class="input-group">
                            <input type="text" name="q" class="form-control" placeholder="Search...">
                            <span class="input-group-btn">
                                <button type="submit" name="search" id="search-btn" class="btn btn-flat">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                    </form>
                    <!-- /.search form -->
         
                <!-- sidebar menu: : style can be found in sidebar.less -->
                <ul class="sidebar-menu" data-widget="tree">
        <li class="header">
        Menu Principal </li>
        
    </ul>
            </section>
            <!-- /.sidebar -->
        </aside>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <h1 ng-bind="Titulo">
                   CODI
                    <small ng-bind="SubTitulo"></small>
                </h1>

            </section>

            <!-- Main content -->
        <section class="content" id="centralContent">

            
<div inform class="inform-animate inform-fixed inform-shadow"></div>

<script type="text/javascript">  
       var gbMsg = ""; 
</script>
