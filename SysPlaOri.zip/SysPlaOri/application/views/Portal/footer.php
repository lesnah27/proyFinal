            </section>
            <!-- /.content -->
        </div>

        <!-- /.content-wrapper -->
        <footer class="main-footer" style="left: 0; bottom: 0; width: 100%; right: 0; ">
            <div class="pull-right hidden-xs">
            </div>
            <strong> Copyright &copy; 2019-<?php  echo date("Y") ?> <span class="text-primary">Sistema CODI </span>.</strong>
        </footer>


        <?php

      
         ?>
        
            <!-- Control Sidebar -->
            <aside class="control-sidebar control-sidebar-dark">
                <!-- Create the tabs -->
                <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
                    <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
                    <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
                </ul>
                <!-- Tab panes -->
                <div class="tab-content">
                    <!-- Home tab content -->
                    <div class="tab-pane" id="control-sidebar-home-tab">
                        <h3 class="control-sidebar-heading">Recent Activity</h3>
                        <ul class="control-sidebar-menu">
                            <li>
                                <a href="javascript:void(0)">
                                    <i class="menu-icon fa fa-file-code-o bg-green"></i>

                                    <div class="menu-info">
                                        <h4 class="control-sidebar-subheading">Cron Job 254 Executed</h4>

                                        <p>Execution time 5 seconds</p>
                                    </div>
                                </a>
                            </li>
                        </ul>
                        <!-- /.control-sidebar-menu -->

                        <h3 class="control-sidebar-heading">Tasks Progress</h3>
                        <ul class="control-sidebar-menu">
                            <li>
                                <a href="javascript:void(0)">
                                    <h4 class="control-sidebar-subheading">
                                        Custom Template Design
                                        <span class="label label-danger pull-right">70%</span>
                                    </h4>

                                    <div class="progress progress-xxs">
                                        <div class="progress-bar progress-bar-danger" style="width: 70%"></div>
                                    </div>
                                </a>
                            </li>
                                <a href="javascript:void(0)">
                                    <h4 class="control-sidebar-subheading">
                                        Update Resume
                                        <span class="label label-success pull-right">95%</span>
                                    </h4>

                                    <div class="progress progress-xxs">
                                        <div class="progress-bar progress-bar-success" style="width: 95%"></div>
                                    </div>
                                </a>
                            </li>
                        </ul>
                        <!-- /.control-sidebar-menu -->

                    </div>
                    <!-- /.tab-pane -->
                    <!-- Stats tab content -->
                    <div class="tab-pane" id="control-sidebar-stats-tab">Stats Tab Content</div>
                    <!-- /.tab-pane -->
                    <!-- Settings tab content -->
                    <div class="tab-pane" id="control-sidebar-settings-tab">
                        <form method="post">
                            <h3 class="control-sidebar-heading">General Settings</h3>

                            <div class="form-group">
                                <label class="control-sidebar-subheading">
                                    Report panel usage
                                    <input type="checkbox" class="pull-right" checked>
                                </label>

                                <p>
                                    Some information about this general settings option
                                </p>
                            </div>
                            <!-- /.form-group -->
                            <!-- /.form-group -->
                            <!-- /.form-group -->
                        </form>
                    </div>
                    <!-- /.tab-pane -->
                </div>
            </aside>
            <!-- /.control-sidebar -->
            <!-- Add the sidebar's background. This div must be placed
                 immediately after the control sidebar -->
            <div class="control-sidebar-bg"></div>


  <div id="temp-html-content">
  </div> 
        
    </div>
    <!-- ./wrapper -->
    <!-- jQuery 3 -->
    <script src="<?php echo base_url(); ?>/webApp/Dist/jquery/js/jquery.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="<?php echo base_url(); ?>/webApp/Dist/jquery-ui/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
        $.widget.bridge('uibutton', $.ui.button);
    </script>   
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script src="<?php echo base_url(); ?>/webApp/Dist/jquery/js/jquery.bootpag.min.js"></script>
    <script>
        $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.7 -->
    <script src="<?php echo base_url(); ?>/webApp/Dist/bootstrap/js/bootstrap.min.js"></script>

    <!-- daterangepicker -->
        <!-- daterangepicker -->
    <script src="<?php echo base_url(); ?>/webApp/Dist/moment/min/moment.min.js"></script>
    <script src="<?php echo base_url(); ?>/webApp/Dist/bootstrap/js/daterangepicker.js"></script>
    <script src="<?php echo base_url(); ?>/webApp/Dist/moment/moment-with-locales.js"></script>

    <!-- datepicker -->

       <script src="<?php echo base_url(); ?>/webApp/Dist/bootstrap/js/bootstrap-datepicker.min.js"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="<?php echo base_url(); ?>/webApp/Dist/bootstrap/js/bootstrap3-wysihtml5.all.min.js"></script>

    <!-- datetimepicker -->
    <script src="<?php echo base_url(); ?>/webApp/Dist/bootstrap/js/bootstrap-datetimepicker.min.js"></script>
    <!-- bootstrap-select -->
    <script src="<?php echo base_url(); ?>/webApp/Dist/select2/select2.min.js"></script>

    <script src="<?php echo base_url(); ?>/webApp/Dist/bootstrap/js/bootstrap-select.min.js"></script>
    <!-- bootstrap-toggle -->
    <script src="<?php echo base_url(); ?>/webApp/Dist/bootstrap/js/bootstrap-toggle.min.js"></script>
    <!-- Bootstrap WYSIHTML5 -->    
    <script src="<?php echo base_url(); ?>/webApp/Dist/bootstrap/js/bootstrap3-wysihtml5.all.min.js"></script>
    <!-- Slimscroll -->
    <script src="<?php echo base_url(); ?>/webApp/Dist/jquery/js/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
       <script src="<?php echo base_url(); ?>/webApp/Dist/fastclick/lib/fastclick.js"></script>
    <!-- AdminLTE App -->
      <script src="<?php echo base_url(); ?>/webApp/Dist/LTE/js/adminlte.min.js"></script>

    <script src="<?php echo base_url(); ?>/webApp/Dist/angularJS/angular.js"></script>
        <script src="<?php echo base_url(); ?>/webApp/Dist/angularJS/angular-sanitize.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>/webApp/Dist/Jcs-auto-validate/jcs-auto-validate.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>/webApp/Dist/Oi.multiselect/multiselect-tpls.min.js"></script><!--angular-oi.multiselect-->
    <script type="text/javascript" src="<?php echo base_url(); ?>/webApp/Dist/sortable/sortable.js"></script>

    <script src="<?php echo base_url(); ?>/webApp/js/App/App.js"></script>
    <script src="<?php echo base_url(); ?>/webApp/js/App/AppValidation.js"></script>
    <script src="<?php echo base_url(); ?>/webApp/js/App/AppFormat.js"></script>
    <script src="<?php echo base_url(); ?>/webApp/js/App/AppTool.js"></script>

    <script src="<?php echo base_url(); ?>/webApp/js/App/Filter/Filters.js"></script>
    <script src="<?php echo base_url(); ?>/webApp/js/App/Directive/Directives.js"></script>
    <script src="<?php echo base_url(); ?>/webApp/js/App/Factory/Factories.js"></script>
    <script src="<?php echo base_url(); ?>/webApp/js/App/Service/Services.js"></script>
    <!-- end taggle -->

   <script src="<?php echo base_url(); ?>/webApp/Dist/animate/angular-animate.min.js"></script>
   <script src="<?php echo base_url(); ?>/webApp/Dist/angular-inform/angular-inform.min.js"></script>
    <!-- end chartjs -->
    <!-- AdminLTE for demo purposes --> -


<!-- ES FIREBASE COn ANgULAr -->
    <script src="https://www.gstatic.com/firebasejs/5.5.5/firebase.js"></script>
    <script src="https://www.gstatic.com/firebasejs/5.5.5/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/5.5.5/firebase-database.js"></script>
<script src="https://www.gstatic.com/firebasejs/5.5.5/firebase-firestore.js"></script>
<script src="https://www.gstatic.com/firebasejs/5.5.5/firebase-messaging.js"></script>
<script src="https://www.gstatic.com/firebasejs/5.5.5/firebase-functions.js"></script>
<!-- AngularFire -->



    <script src="<?php echo base_url(); ?>/webApp/Dist/bootstrap/js/boostrap-waiting.js"></script>
   <script src="<?php echo base_url(); ?>/webApp/Dist/jquery/js/jquery.blockUI.js"></script>
   <script src="<?php echo base_url(); ?>/webApp/Dist/datatables.net/js/jquery.dataTables.min.js"></script>
   <script src="<?php echo base_url(); ?>/webApp/Dist/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>

       <script type="text/javascript" src="<?php echo base_url(); ?>/webApp/Dist/fileinput/js/fileinput.js"></script>
        <script src="<?php echo base_url(); ?>/webApp/Dist/LTE/js/website.js"></script>

    <script>


        if (typeof (gTechApp) == "undefined") {
            console.log("No Controller");
        } else {
            (function () { 
                gTechApp.Main(); 
            })();

        }
    </script>

      <script type="text/javascript">
      //custom select box 
  </script>

</body>

</html>