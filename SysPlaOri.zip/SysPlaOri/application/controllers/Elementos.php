<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Elementos extends CI_Controller {

    public function index()
    {
      if(!$this->session->userdata("sUser")){
          redirect("Portal");
          return 0
      }

    }


// Return Json
     public function getData(){
       if(!$this->session->userdata("sUser")){
         echo json_encode( array('IsOk' => false, 'IsSession'=> false ));
          return 0
      }

      $this->load->model("elementos_model", "elem_"); 

     $lista =   $this->elem_->obtnerListaElementosPorUsuarioID(1);
       echo json_encode($lista); 


      // Aqui Obtenermos las informacines dle modelo de Elementos


     }





}
