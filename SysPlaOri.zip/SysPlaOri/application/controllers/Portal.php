<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Portal extends CI_Controller {

    public function index()
    {
      if(!$this->session->userdata("sUser")){
        $this->load->view('Portal/login');
        return 0;
      }

          redirect("Portal/Panel");

    }

    public function login(){

// Provicinlal hasto conetarnos a la db
     $control = array('Correo' => "lesnah27@gmail.com", "Password"=> md5("123") );


     if($this->input->post("Email") && $this->input->post("Password")){
        $user =  $this->input->post("Email"); 
        $pass = $this->input->post("Password");

       if($user == $control["Correo"] && md5($pass) == $control["Password"]){

        $this->session->set_userdata("sUser",  $control); 

                echo json_encode(array('IsOk' =>true ));
                return 0;

        } 
     }

echo  json_encode(array('IsOk' =>false ));
        return 0;

    }


    public function logOut(){
        $this->session->sess_destroy(); 
         redirect("Portal");

    }


    public function panel()
    {
       if(!$this->session->userdata("sUser")){
        redirect("Portal/");
        return;
       } 
        

        $this->load->view('Portal/header');
        $this->load->view('Portal/Panel');
        $this->load->view('Portal/footer');
    }





}
