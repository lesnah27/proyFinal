
<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Elementos_Model extends CI_Model {


    function __construct() {
     //   $this->load->database('ptp');
        parent::__construct();
    }


     public function obtnerListaElementosPorUsuarioID($usuarioID){

     	// Consulta a las tabla de lementos asosociado a la planra dle usuario.
     // 	TipoElemento: 1: Tinaco 2: Bomba, 3: Sensores 4: filtros 5: Sistema Omosis 6: maquina Term

     	$listElementos = array(
     	 array('EmpresaID' =>1, "PlantaID", "TipoElemento"=> 1, "ElementoID"=> 1, "Estatus"=> 1, "TieneParametos"=>false, "ValorMin"=>1 "ValorMaximo"=> 0, "NecesitaArranque"=> false), 

     	 // Sensores
     	  array('EmpresaID' =>1, "PlantaID", "TipoElemento"=> 2, "ElementoID"=> 2, "Estatus"=> 1, "TieneParametos"=>false, "ValorMin"=>1 "ValorMaximo"=> 0, "NecesitaArranque"=> false ),
     	       	  array('EmpresaID' =>1, "PlantaID", "TipoElemento"=> 2, "ElementoID"=> 7, "Estatus"=> 1, "TieneParametos"=>false, "ValorMin"=>1 "ValorMaximo"=> 0, "NecesitaArranque"=> false ),

     	       	  array('EmpresaID' =>1, "PlantaID", "TipoElemento"=> 2, "ElementoID"=> 8, "Estatus"=> 1, "TieneParametos"=>false, "ValorMin"=>1 "ValorMaximo"=> 0, "NecesitaArranque"=> false ),

     	       	   array('EmpresaID' =>1, "PlantaID", "TipoElemento"=> 2, "ElementoID"=> 9, "Estatus"=> 1, "TieneParametos"=>false, "ValorMin"=>1 "ValorMaximo"=> 0, "NecesitaArranque"=> false ),


     	   array('EmpresaID' =>1, "PlantaID", "TipoElemento"=> 3, "ElementoID"=> 3, "Estatus"=> 1, "TieneParametos"=>false, "ValorMin"=>1 "ValorMaximo"=> 0, "NecesitaArranque"=> false ),
     	    array('EmpresaID' =>1, "PlantaID", "TipoElemento"=> 4, "ElementoID"=> 4, "Estatus"=> 1, "TieneParametos"=>false, "ValorMin"=>1 "ValorMaximo"=> 0, "NecesitaArranque"=> false ),
     	     array('EmpresaID' =>1, "PlantaID", "TipoElemento"=> 5, "ElementoID"=> 5, "Estatus"=> 1, "TieneParametos"=>false, "ValorMin"=>1 "ValorMaximo"=> 0, "NecesitaArranque"=> false ),
     	      array('EmpresaID' =>1, "PlantaID", "TipoElemento"=> 6, "ElementoID"=> 6, "Estatus"=> 1, "TieneParametos"=>false, "ValorMin"=>1 "ValorMaximo"=> 0, "NecesitaArranque"=> false )

     	);

     	return $listElementos; 


     }
