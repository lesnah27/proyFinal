var prueba;

(function () {
    var $ang = appAng;

    var $app = new app();
    var $sys = $app.System;
    var $format = $app.Format;

     /*CRUD*/
    $ang.factory('AppCrud', function ($http) {
        
        //var MaxRowsPerPage = 50;
        var Crud = {
            currentCulture: $('#currentCulture').val(),
            waitingMsg: $('#waitingMsg').val(),
            confirmDelete: $('#confirmDeleteMsg').val(),
            form: {},
            modo: 0,
            hash: {},
            MaxRowsPerPage: 50,
            selectedIndex: 0,
            esValido: false,
            vldt: null,
            $Form: {},
            $Pagination: {},
            $configPagination: { maxRowsPage: 15, maxVisiblePage: 8 },
            totalPages: 0,
            pageCallBack: function () { },
            option: {},
            
            $Search: { send: false, url: "", w: "" },

            initt: function (options) {

                $("#formulario").hide();
                $("#ListMantenimiento").show();

                Crud.option = options; 
                if ("searchUrl" in options) {
                    Crud.$Search.url = options.searchUrl;
                }
                  Crud.renderPaginate(options);
            },

            setPages: function (opt) {
                Crud.$configPagination.maxRowsPage = opt.maxRowsPage;
                Crud.$configPagination.totalResult = opt.totalResult;
                Crud.pageCalculate(opt);

            },

            pageCalculate: function (opt) {
                // Calculador a de variavbles          
                if ("totalResult" in opt) {
                    var valPag = opt.totalResult / Crud.$configPagination.maxRowsPage
                    if (valPag < 1) {
                        Crud.totalPages = parseInt(1);
                    } else {
                        var dif = valPag - parseInt(valPag);
                        if (dif > 0) {
                            Crud.totalPages = parseInt(valPag) + 1;
                        } else {
                            Crud.totalPages = parseInt(valPag);
                        }
                    }


                    Crud.$Pagination.bootpag({
                        total: (Crud.totalPages),
                        maxVisible: 10,
                        page: opt.num,
                        leaps: true,
                        firstLastUse: true,
                        first: '←',
                        last: '→'
                    });
                }
            },

            Buscar: function (cEvent) {

                //console.log("Buscar Evento... "); 
              //  Crud.$Search.send
                switch (cEvent.type) {
                    case "keypress":                       
                        if (cEvent.keyCode == 13) {
                            form = { next: 0, max: Crud.$configPagination.maxRowsPage };
                            form.filtro = Crud.$Search.w;
                            // Esta parte es para filtro adicional
                            if (Crud.$Search.y != undefined)
                                form.otroFiltro = Crud.$Search.y;
                            // Finaliza aqui

                            $.blockUI($('#waitingMsg').val());
                            $http({
                                method: 'GET',
                                url: Crud.option.searchUrl,
                                params: form
                            }).then(function (res) { Crud.pageCallBack(res.data, 1); $.unblockUI(); }, function errorCallback(response) {
                            });
                        }
                        break;
                    case "click":
                        $.blockUI($('#waitingMsg').val());
                        form = { next: 0, max: Crud.$configPagination.maxRowsPage };
                        form.filtro = Crud.$Search.w;
                        // Esta parte es para filtro adicional
                        if (Crud.$Search.y != undefined)
                            form.otroFiltro = Crud.$Search.y;
                        // Finaliza aqui
                        $http({
                            method: 'GET',
                            url: Crud.option.searchUrl,
                            params: form
                        }).then(function (res) { Crud.pageCallBack(res.data, 1); $.unblockUI(); }, function errorCallback(response) {
                        });

                        break;
                }

            },

            renderPaginate: function (option) {
                // configuracion de la cantidad de registros, cantidad de Paginas 
                Crud.pageCallBack = option.callback;


                Crud.$Pagination = $('#page-selection-APP').bootpag({
                    total: 0,
                    page: 1,
                    maxVisible: 10,
                    leaps: true,
                    firstLastUse: true,
                    first: '←',
                    last: '→'
                }).on('page', function (event, num) {

                    var innerUrl = option.url;
                    form = { next: (num - 1), max: Crud.$configPagination.maxRowsPage };
                    form.filtro = Crud.$Search.w;
                    // Esta parte es para filtro adicional
                    if (Crud.$Search.y != undefined)
                        form.otroFiltro = Crud.$Search.y;
                    $.blockUI($('#waitingMsg').val());
                    $http({
                        method: 'GET',
                        url: innerUrl,
                        params: form
                    }).then(function (res) { Crud.pageCallBack(res.data, num); $.unblockUI(); }, function errorCallback(response) {
                    });
                   
                });
            },

            Cancelar: function () {
                $("#formulario").hide();
                $("#ListMantenimiento").show();
            },

            Editar: function (modo) {
                $("#formulario").show();
                $("#ListMantenimiento").hide();
                Crud.modo = modo;
            },
            reset: function () {
                $("#formulario").hide();
                $("#ListMantenimiento").show();

                for (var i in Crud.form) {
                    if (Crud.form.hasOwnProperty(i)) {
                        if (!(i in Crud.hash)) {
                            Crud.form[i] = "";
                        }
                    }
                }
            },

            setForm: function (obj) {
                Crud.form = obj;

                for (var i in Crud.form) {
                    if (Crud.form.hasOwnProperty(i)) {
                        if ($.isNumeric(Crud.form[i])) {
                            Crud.form[i] = parseFloat(Crud.form[i]);
                        }
                        // Para el tema de la Fecha Modifica.
                        if (i == "FechaModifica" || i == "FechaModificacion" || i == "fechamodifica") {
                            Crud.form[i] = "1999-01-01";
                        }
                    }

                }
            },

            setFormSelected: function (obj, numbers) {
                Crud.form = obj;

                for (var i in Crud.form) {
                    if (Crud.form.hasOwnProperty(i)) {
                        if ($.isNumeric(Crud.form[i]) && numbers.hasOwnProperty(i)) {
                            Crud.form[i] = parseFloat(Crud.form[i]);
                        }
                        // Para el tema de la Fecha Modifica.
                        if (i == "FechaModifica" || i == "FechaModificacion" || i == "fechamodifica") {
                            Crud.form[i] = "1999-01-01";
                        }
                    }

                }
            },

            formatObjForm: function (item, nameVar) {
                var rest = {};
                if (typeof nameVar === 'undefined' || nameVar === null) {
                    rest['objeto'] = item;
                    // return {objeto: form }
                } else {
                    rest[nameVar] = item;
                }

                for (var i in Crud.hash) {
                    if (Crud.hash.hasOwnProperty(i)) {
                        rest[i] = Crud.hash[i];
                    }
                }

                return rest;

            },

            getForm: function (nameVar) {
                // Sus manos martille.
                var rest = {};
                if (typeof nameVar === 'undefined' || nameVar === null) {
                    rest['objeto'] = Crud.form;
                    // return {objeto: form }
                } else {
                    rest[nameVar] = Crud.form;
                }


                for (var i in Crud.hash) {
                    if (Crud.hash.hasOwnProperty(i)) {
                        rest[i] = Crud.hash[i];
                    }
                }
                return rest;
            },

            setHash: function (name, val) {
                Crud.hash[name] = val;
                // Crud.form[name.trim()] = val.trim();
            },

            validate: function () {
                for (var form in Crud.$Form) {
                    if ((Crud.$Form[form].hasOwnProperty("$invalid") && Crud.$Form[form].$invalid)) {
                        $.blockUI({
                            message: $('<div style="size: font-size: 20px;"> <span style="display: block; margin-bottom: 1px"><b>Campos incompletos </b></span>  <p>Hay campos obligatorios que deben ser completados </p></div>'),
                            fadeIn: 700,
                            fadeOut: 700,
                            timeout: 4000,
                            showOverlay: false,
                            centerY: false,
                            css: {
                                width: '350px',
                                top: '60px',
                                left: '',
                                right: '10px',
                                border: 'none',
                                padding: '5px',
                                backgroundColor: '#000',
                                '-webkit-border-radius': '10px',
                                '-moz-border-radius': '10px',
                                opacity: 0.85,
                                color: '#fff'
                            }
                        });
                        return false;
                    }
                }
                return true;
            },

            validateCustom: function (errors) {
                for (var x = 0; x < errors.length; x++) {
                    for (var form in Crud.$Form) {
                        if (Crud.$Form[form].$invalid && Crud.$Form[form].$error[errors[x].name] != undefined) {
                            $.blockUI({
                                message: $('<div style="size: font-size: 20px;"><span style="display: block; margin-bottom: 5px"><b>' + errors[x].msg['title'] + '</b></span><p>' + errors[x].msg['text'] + '</p></div>'),
                                fadeIn: 700,
                                fadeOut: 700,
                                timeout: 4000,
                                showOverlay: false,
                                centerY: false,
                                css: {
                                    width: '350px',
                                    top: '60px',
                                    left: '',
                                    right: '10px',
                                    border: 'none',
                                    padding: '5px',
                                    backgroundColor: '#000',
                                    '-webkit-border-radius': '10px',
                                    '-moz-border-radius': '10px',
                                    opacity: 0.85,
                                    color: '#fff'
                                }
                            });

                            return false;
                        }
                    }
                }

                return true;
            }
        };
        return Crud;
    });


    $ang.factory('AppSession', function () {

        var miSession = {
            strict: true,
            form: {},
            pageCallBack: function () { },

            $Search: { send: false, url: "", w: "" },

            initt: function (options) { },
            IsSession: function (res, callback) {
                if ("IsSession" in res) {
                    if (res.IsSession == false) {
                        
                        if(typeof(callback) == "function"){
                            callback(); 
                        }

                    setTimeout(function(){ miSession.refrescar(); }, 1500);

                        return false;
                    }
                } else {
                    if (miSession.strict === true) {
                        miSession.refrescar();
                        return false;
                    }
                }
            },
            refrescar: function () {
                            // Windows Reload     
                document.location.reload(true);
            }
        };
        return miSession;

    });


    /*Http*/
    $ang.factory('AppHttp', function ($http) {
        var appHttp = {};

          errorCallback = function (res) {
            };

        appHttp.Get = function (url, data, callback) {
            $http({
                method: 'GET',
                url: url,
                params: data
            }).then(function (res) { callback(res.data); }, function errorCallback(response) {
                // Error Pos
            });
            // .success(callback);
        };

        appHttp.Post = function (url, data, callback, errorFunct) {

            errorCallback = function (res) {
                $.unblockUI(); 
                alert("Ocurrio Un error."); 

            };
            if(typeof(errorFunct) == "function"){
                errorCallback = errorFunct; 
            }


            $http({
                method: 'POST',
                url: url,
                // data: data
                data: $.param(data),
                headers: {
                  'Content-Type': 'application/x-www-form-urlencoded'
                  }
            }).then(function (res) { callback(res.data); }, errorCallback );

          //   $http.post(url, data).then(function (res) { callback(res.data); }, errorCallback);
            //  $http.post(url, data).success(callback);

        };

        appHttp.Redirect = function (url) {
            window.location.href = url;
        }

        appHttp.Reload = function () {
            window.location.reload();
        }

        return appHttp;

    })
})();