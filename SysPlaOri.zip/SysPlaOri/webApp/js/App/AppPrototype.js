(function () {
    /*String*/
    var str = String.prototype;
    /*****************************************************
    $str.prototype.repeat
    Parameters:
        times : 0
    ******************************************************/
    str.repeat = function (times) {
        return new Array(times + 1).join(this)
    }

    str.replaceAll = function (str1, str2, ignore) {
        return this.replace(new RegExp(str1.replace(/([\/\,\!\\\^\$\{\}\[\]\(\)\.\*\+\?\|\<\>\-\&])/g, "\\$&"), (ignore ? "gi" : "g")), (typeof (str2) == "string") ? str2.replace(/\$/g, "$$$$") : str2);
    }

    /*Object*/
    var objp = Object.prototype;
    /*****************************************************
    $Object.prototype.where

    Parameters:
        filtro : "
                  x.variable == valor 
                  && x.variable == valor
                  || x.variable == valor
                  
                  ",

    ******************************************************/
    Object.where = function (filtro) {
        var obj = this;

        if (Array.isArray(obj))
            return obj.filter(function (x) { return eval(filtro) });

    }

    /*Jquery*/
    var Jqy = $.prototype

    /*****************************************************
     $$.prototype.where

     Parameters:
         truncateLenght : 0

     ******************************************************/
    Jqy.truncate = function (truncateLenght) {
        var obj = $(this);

        obj.each(function () {
            var obj = $(this);
            var text = obj.text();
            var apply = (text.length <= truncateLenght) ? false : true;

            if (apply)
                obj.prop("title", text);

            obj.text(
					text.substring(0, apply ? truncateLenght : text.length) + (apply ? "..." : "")
					);
        })
    }

})()
