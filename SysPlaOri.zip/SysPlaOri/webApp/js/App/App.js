var appAngularDependecies = ["oi.multiselect", "inform", 'ngAnimate', 'inform-exception', 'ngSanitize'];
var app = function () {
    var instance;
    app = function app() {
        return instance;
    };
    app.prototype = this;
    instance = new app();
    instance.constructor = app;
    return instance;
};

var appAng = angular.module("AppSupply", appAngularDependecies, function ($compileProvider) {
    $compileProvider.directive('compile', function ($compile) {
        return function (scope, element, attrs) {
            scope.$watch(
                function (scope) {
                    return scope.$eval(attrs.compile);
                },
                function (value) {
                    element.html(value);
                    $compile(element.contents())(scope);
                }
            );
        };
    });
})
/*.config(['$compileProvider', function ($compileProvider) {
    $compileProvider.debugInfoEnabled(false);
}])*/;
// .run();
//1 - Validation
//2 - Format
//3 - Tool
//4 - Prototype
//5 - System

/*
Grequis Xavier Pérez
Desarrollador de Software.
Celular: 849 356.6520
Tel. 809-548-0617

e-mail: gxperezf@gmail.com
*/
