
(function () {
    var $ang = appAng;
    var $app = new app();
    var $tool = $app.Tool;
    var $format = $app.Format; //ObjectcleanValue
    //var $sysconfig = $sys.Config;
   //   var $smt = $sys.Enum.MessageType;


    /*File Uploud*/
    $ang.service('AppFileUpload', ['$http', '$log', function ($http, $log) {
        this.uploadFileToUrl = function (file, data, uploadUrl, successCallback, erroCallback) {
            var formData = new FormData();
            //Add our file
            formData.append('file', file);

            //Add our data
            formData.append('data', angular.toJson(data));

            $http.post($sysconfig.ApplicationPath + uploadUrl, formData, {
                transformRequest: angular.identity,
                headers: { 'Content-Type': undefined }
            })
            .success(function (data) {
                successCallback(data);
            }).error(function () {
                erroCallback();
            });
        };
    }
    ]);

    
})();