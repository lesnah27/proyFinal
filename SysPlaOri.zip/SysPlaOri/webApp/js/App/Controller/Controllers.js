/**
Autor: Grequis Xavier Perez.
Descripcion: Separate Logistica of Server.

*/



var gTechApp = {
    ctrls: [], 
    AddController: function (name, vars, callFunction) {
        gTechApp.ctrls.push({ name: name, vars: vars, call: callFunction});
    },

    Main: function () {
        var $ang = appAng;
        var $app = new app();
        var $tool = $app.Tool;
        var $format = $app.Format;
        
        gTechApp.ctrls.forEach(function (ele) {
            $ang.controller(ele.name, ele.vars);
        });
   }
};

gTechApp.AddController('AppController', ['$scope', '$http', 'AppHttp', '$compile',  function ($scope, $http, appHttp, $compile) {
    function http(url, data, callback) {
        appHttp.Get(url, data, callback)
    }

      // Initialize Firebase
  // TODO: Replace with your project's customized code snippet
   $scope.config = {
    apiKey: "AIzaSyBRFNy7kcOPRrg8qLyngfVc2OAZS9-KRS8",
    authDomain: "pruev1-b7087.firebaseapp.com",
    databaseURL: "https://pruev1-b7087.firebaseio.com",
    projectId: "pruev1-b7087",
    storageBucket: "pruev1-b7087.appspot.com",
    messagingSenderId: "1097633572611"
  };

  $scope.firebase = firebase;  

 // $scope.objeto1 = {Nombre: "Jose", "Apellido" : "Apellido"}; 


  $scope.hiceClick = function(){
    
   // alert("Ejecuto"); 
  }; 

    $scope.MenuItemName = "";
    $scope.MenuItems = [];
    $scope.Notificaciones = [];
    $scope.NotificacionesTotalNoLeido = 0;
    $scope.PortalConfigs = [];
    $scope.AppHtml = "";

    $scope.Titulo = "";
    $scope.SubTitulo = "";
    $scope.sOrganigrama = {};
     $scope.sCalendarioActivo = {};
    $scope.clubSelected = 0;


    $scope.MenuHtml = "";

    $scope.user = {
        Email: "", 
        Password: ''
    }; 


    $scope.login = function(){

        console.log("Click en Login"); 

        appHttp.Post(base_url + "portal/login", $scope.user, function(res){
            console.log(res);
            if(res.IsOk){
                location.reload(); 
                return 0;                
            } 
            alert("Usuarios Incorrecto."); 

        }); 

    }; 



    $scope.sendCredencial = function(){



        var provider = new $scope.firebase.auth.GoogleAuthProvider();

        $scope.firebase.auth().signInWithPopup(provider).then(function(result) {
  // This gives you a Google Access Token. You can use it to access the Google API.
  var token = result.credential.accessToken;
  // The signed-in user info.
  var user = result.user;
  // ...
}).catch(function(error) {
  // Handle Errors here.
  var errorCode = error.code;
  var errorMessage = error.message;
  // The email of the user's account used.
  var email = error.email;
  // The firebase.auth.AuthCredential type that was used.
  var credential = error.credential;
  // ...
});


/*
// $scope.firebase.auth().signInWithEmailAndPassword($scope.user.Email, $scope.user.Password).catch(function(error) {
  // Handle Errors here.
  var errorCode = error.code;
  var errorMessage = error.message;
  // ...
});

*/
    }

    $scope.inicial = function () {
       //  
     $scope.firebase.initializeApp($scope.config);       

    };

    $scope.Planta = {
        img: "Animation.png",
        Status: 0, 
        Presion: 0, 
        Volumen: 0, 
        Log: [{Msg: "", Tiempo:0}]
    };


    $scope.InicioPlanta = function(){

          if( $scope.Planta.Status == 1){
            alert("La planta y esta encendida."); 
            return 0 ;
          }

        if(confirm("Seguro desea arracar o inicar la planta")){
            $scope.Planta.Status = 1;
             $scope.Planta.img = "Animation.gif";
             // TODO: Interaccion con Firebese y los dipositivos.
             $scope.Planta.Log.push({Msg:"Inicio Planta", Tiempo: 1});
           // $scope.sendCredencial(); 

        }
    }; 

    $scope.DetenerPlanta = function(){
        if( $scope.Planta.Status == 0){
            alert("La planta no se puede deterner porque no esta encendida o no ha iniciado."); 
            return 0 ;
          }

            if(confirm("Seguro desea Detener la planta")){
            $scope.Planta.Status = 0;
             $scope.Planta.img = "Animation.png";
             // TODO: Interaccion con Firebese y los dipositivos.
              $scope.Planta.Log.push({Msg:"Detuvo Planta", Tiempo: 1}); 
         }
    }; 

    $scope.ResetPlanta = function(){

        if(confirm("Seguro desea Reiniciar la planta")){
            $scope.Planta.Status = 1;
             $scope.Planta.img = "Animation.gif";
             // TODO: Interaccion con Firebese y los dipositivos.
               $scope.Planta.Log.push({Msg:"Reset Planta", Tiempo: 1});
                    $scope.Planta.Log.push({Msg:"Detuvo Planta", Tiempo: 1});
                      $scope.Planta.Log.push({Msg:"Inicio Planta", Tiempo: 1});  
                 //     $scope.sendCredencial();

        }
    }

    $scope.RenderMenu = function (list) {
        var mP = {};
        var mO = {};
        var renderSub = function (list) {
            var rtHtm = "";
            rtHtm += '<ul class="treeview-menu" style="display: none;">';

            list.forEach(function (elem) {
                var hasChild = false;
                if (elem.IDMenu in mO) {
                    rtHtm += '<li class="treeview">';
                    hasChild = true; 
                } else {
                    rtHtm += "<li>";
                }
                rtHtm += getTipoLink(elem) + '<i class="' + elem.IconClass + '"></i> <span>' + elem.Nombre + '</span>';
                if (hasChild) {
                    rtHtm += '<span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>';
                    rtHtm += renderSub(mO[elem.IDMenu]);
                } else {
                    rtHtm += '</a>'; 
                }

                rtHtm += "</li>";

            });
            rtHtm += '</ul>';
            return rtHtm;

        };

        var getTipoLink = function (el) {
            switch (el.LinkTipo) {
                case 1:
                    return ' <a href="#">';
                    break;
                case 2:
                    return '<a href="' + base_url + el.Ruta + '">';
                    break;
                default:
                    return ' <a href="#" ng-click="SetMainIframe(' + "'" + el.Ruta + "'" + ', ' + "'" + el.Nombre + "'" + ')">';
                    break;
            }
        }

        list.forEach(function (element) {
            // Llenar los Padres.
            if (element.IDMenuPadre == 0 || element.IDMenuPadre == null) {
                if (!(element.IDMenu in mP)) {
                    mP[element.IDMenu] = { Data: element, subMenu: {} };
                }
            } else {
                // Todos los Menus Original
                if (!(element.IDMenuPadre in mO)) {
                    mO[element.IDMenuPadre] = [];
                }
                mO[element.IDMenuPadre].push(element);
            }
        });
        // Render menus.
        var trHtml = "";

        var sortable = [];
        //console.log(mP);

        for (var i in mP) {
            sortable.push([mP[i].Data.Nombre, mP[i]]);
        }

        //console.log(sortable);

        sortable.sort(function (a, b) {
            var nameA = a[0].toLowerCase();
            var nameB = b[0].toLowerCase();

            if (nameA < nameB)
                return -1;
            if (nameA > nameB)
                return 1;
            // names must be equal
            return 0;
        });

        //console.log(sortable);

        sortable.forEach(function (item) {
            //console.log(item, item[1]);
            trHtml += '<li class="treeview">';
            trHtml += getTipoLink(item[1].Data) + '<i class="' + item[1].Data.IconClass + '"></i> <span>' + item[0] + '</span>';
                if (item[1].Data.IDMenu in mO) {
                    trHtml += '<span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>';
                    trHtml += renderSub(mO[item[1].Data.IDMenu]);
                } else { trHtml += "</a>" }
                trHtml += '</li>'; // mP[i]
        });

        //for (var i in mP) {
        //    forVar++;
        //    if (mP.hasOwnProperty(i)) {
        //        ifVar++;
        //        trHtml += '<li class="treeview">';
        //        trHtml += getTipoLink(mP[i].Data) + '<i class="' + mP[i].Data.IconClass + '"></i> <span>' + mP[i].Data.Nombre + '</span>';
        //        if (mP[i].Data.IDMenu in mO) {
        //            trHtml += '<span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>';
        //            trHtml += renderSub(mO[mP[i].Data.IDMenu]);
        //        } else { trHtml += "</a>" }
        //        trHtml += '</li>'; // mP[i]
        //    }
        //}
        return trHtml;
    };

    $scope.Arreglo = [];

    $scope.texto = "Buenos dias";

    $scope.GetHomeIndex = function () {
        var link = "Portal/HomePages";
        appHttp.Get(link, null, (function (res, status) {
            $scope.AppHtml = res;
        }));
    };

    $scope.goFullLink = function(url){

        var link = base_url + url; 
        window.location.href = link; 
return 0; 

    }

    $scope.SetMainIframe = function (link, title) {

        $scope.Titulo = title;
        $scope.SubTitulo = "Panel";

        $("#centralContent").html('<iframe src="' + link + '" height="750" width="100%"></iframe>');
    }

    $scope.SetMain = function (link) {
        var link = base_url + link;
        for (var i = gbl_Master_setInvervalLog.length - 1; i >= 0; i--) {
            clearInterval(gbl_Master_setInvervalLog[i]);
        }

        appHttp.Get(link, null, (function (res, status) {
            $scope.AppHtml = res;
        }));
    }

    $scope.SetMenuItemName = function (menuItemName) {
        $scope.MenuItemName = menuItemName;
    }

    $scope.ChangeConfig = function (configID) {
        if ($sysCrud.GetState() != null) {
            $sysUtil.ShowInfoMessage($sysMsg.FinalizaCrud);
            return;
        }
        appHttp.Post(base_url + 'Home/ChangeConfig', { configID: configID }, function (res) {
            if (res.IsOk) {
                appHttp.Reload();
            }
            else {
                console.log("Error: ChangeConfig");
            }
        });
    }

    $scope.Redirect = function (link) {
        if ($sysCrud.GetState() != null) {
            $sysUtil.ShowInfoMessage($sysMsg.FinalizaCrud);
            return;
        }
        appHttp.Redirect(link);
    }

    $scope.AppInit = function () {
        http("Notificacion/Obtener", null, function (res) {
            $scope.Notificaciones = res.Notificaciones;
            $scope.NotificacionesTotalNoLeido = res.CantidadTotalNoLeido;
        });
    }


    $scope.EliminarNotificacion = function (index) {
        http("Notificacion/Eliminar", { notificacionID: $scope.Notificaciones[index].NotificacionID }, function (res) {
            if (res.IsOk) {
                $scope.Notificaciones.splice(index, 1);
                $scope.NotificacionesTotalNoLeido--;
            }
            else {
                $sysUtil.ShowDangerMessage(res.Msg);
            }
        });
    };

    $scope.geturLogoTipoClub = function(clubTipo){
        var iurl = base_url + "webApp/img/icono/" + clubTipo + '_clubicon.png';
        return "<img style='width: 30px;'  src='"+ iurl + "'>";         

       //  return iurl;       
    }

    $scope.getBtnClassPorLogo = function(logo){
         var iurl = base_url + "webApp/img/Logos/class/" + logo;
        return "<img style='width: 30px;'  src='"+ iurl + "'>";         

    };
    //   $scope.GetHomeIndex();

    // Global Metodos.
    

    $scope.calcularEdad = function (fecha) {
                var hoy = new Date();
                var cumpleanos = new Date(fecha);
                var edad = hoy.getFullYear() - cumpleanos.getFullYear();
                var m = hoy.getMonth() - cumpleanos.getMonth();

                if (m < 0 || (m === 0 && hoy.getDate() < cumpleanos.getDate())) {
                    edad--;
                }
                if(isNaN(edad)){
                    return -1;
                }
                return edad;
        };

    //00000000000000000000
$scope.Gbl_GetImagenPersona = function(item){ 
        return '<img src="' + base_url + 'Persona/getImgPersonByKey?link=' + item  + '" class="img-circle" height="50" width="50">';  
};

}]);

gTechApp.AddController('Controller', ['$scope', '$http', 'AppHttp', '$compile',  function ($scope, $http, appHttp, $compile) {
    function http(url, data, callback) {
        appHttp.Get(url, data, callback)
    }

    $scope.initt = function(){
        
    }    
}]);

